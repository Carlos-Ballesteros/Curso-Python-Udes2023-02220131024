"""
from tkinter import Tk #Ventanas
from tkinter import Frame #Marco
from tkinter import Label #Texto
from tkinter import Entry #Campo de formulario
from tkinter import Button #No necesitas que te explique este lol
"""


def Enviar():
    nombre = EntryNombre.get()
    apellido = EntryApellido.get()
    id = EntryId.get()
    descripcion = txtDescripcion.get(1.0, 'end')
    rdValue = rdValues.get()
    print(str(nombre)+ "\n" + str(apellido) + "\n" + str(id) + "\n" + str(descripcion) + "\n" + str(rdValue))
    aux1 = chk1.get()
    if aux1:
        print("!")
    aux2 = chk2.get()
    if aux2:
        print("\"")
    aux3 = chk3.get()
    if aux3:
        print("#")

def Limpiar():
    EntryNombre.delete(0, 'end')
    EntryApellido.delete(0, 'end')
    EntryId.delete(0, 'end')
    txtDescripcion.delete(1.0, 'end')
    rdB1.deselect()
    rdB2.deselect()
    rdB3.deselect()
    chkB1.deselect()
    chkB2.deselect()
    chkB3.deselect()
    
import tkinter as Ventana

Formulario = Ventana.Tk()
Formulario.title("Beep Boop")
Formulario.geometry('')
Formulario.config(bg='#000')

#Logo/Titulo#
contTitulo = Ventana.Frame(Formulario,bg='#000', padx=100)
contTitulo.grid(row=0, columnspan=2)

LabelTitulo = Ventana.Label(contTitulo, bg = '#000', fg = '#FFF', text="*El mejor titulo imaginable*", padx=100,pady=10)
LabelTitulo.grid(column=1, row=0)

img = Ventana.PhotoImage(file = "Widgets\image.png")
imagen = Ventana.Label(contTitulo, image=img, height=100, width=100)
imagen.grid(column=0, row=0)




#Labels and Entrys TxtFields#
contTxtFields = Ventana.Frame(Formulario, bg='#000', padx=50)
contTxtFields.grid(column=0,row=1)

LabelNombre = Ventana.Label(contTxtFields, text="Ingrese Nombre",bg='#000', fg='#fff')
LabelNombre.grid(row=0,column=0)
EntryNombre = Ventana.Entry(contTxtFields)
EntryNombre.grid(row=0,column=1)

LabelApellido = Ventana.Label(contTxtFields, text="Ingrese Apellido",bg='#000', fg='#fff')
LabelApellido.grid(row=1,column=0)
EntryApellido = Ventana.Entry(contTxtFields)
EntryApellido.grid(row=1,column=1)

LabelId = Ventana.Label(contTxtFields, text="Ingrese Id",bg='#000', fg='#fff')
LabelId.grid(row=2,column=0)
EntryId = Ventana.Entry(contTxtFields)
EntryId.grid(row=2,column=1)


#Labels and TxtArea#
contTxtArea = Ventana.Frame(Formulario, bg='#000', padx=100, pady=5)
contTxtArea.grid(column=1,row=1)

LabelTxtArea = Ventana.Label(contTxtArea,bg='#000', fg='#fff', text="Descripcion")
LabelTxtArea.grid(row = 0)

descripcion = Ventana.StringVar
txtDescripcion = Ventana.Text(contTxtArea, bg ='#fff', height = 5, width = 10)
txtDescripcion.grid(row = 1)

#Radio Buttons#
contRadButton = Ventana.Frame(Formulario, bg='#000', padx=100,pady=5)
contRadButton.grid(column=0,row=2)

rdValues = Ventana.StringVar()
rdB1 = Ventana.Radiobutton(contRadButton, text="A", variable=rdValues , value="A")
rdB1.pack()
rdB2 = Ventana.Radiobutton(contRadButton, text="B", variable=rdValues , value="B")
rdB2.pack()
rdB3 = Ventana.Radiobutton(contRadButton, text="C", variable=rdValues , value="C")
rdB3.pack()

#Check Buttons #
contChkButton = Ventana.Frame(Formulario, bg='#000')
contChkButton.grid(column=1,row=2)

chk1= Ventana.BooleanVar()
chkB1 = Ventana.Checkbutton(contChkButton, text="A", variable=chk1)
chkB1.grid(row=0)

chk2= Ventana.BooleanVar()
chkB2 = Ventana.Checkbutton(contChkButton, text="B", variable=chk2)
chkB2.grid(row=1)

chk3= Ventana.BooleanVar()
chkB3 = Ventana.Checkbutton(contChkButton, text="C", variable=chk3)
chkB3.grid(row=2)


#Botones Datos#x
contButton1 = Ventana.Frame(Formulario, bg='#FFF')
contButton1.grid(row=3, columnspan=2)

Button = Ventana.Button(contButton1, text="Limpiar", command=Limpiar)
Button.grid(column=0, row=0)

Button = Ventana.Button(contButton1, command=Enviar, text="Enviar")
Button.grid(column=1,row=0)



Formulario.mainloop()















#                                                                                                                tu tururu ru tu